<?php namespace App\Models\admin_models;
use CodeIgniter\Model;
class Sub_category_model extends Model
{
    protected $table      = 'sub_category';
    protected $primaryKey = 'id';
    protected $allowedFields = ['id','name','category_id','display_order','description','is_deleted'];
    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;
    
    public function get_category_info() { 
        
        echo 'helo';die;
        
            $db      = \Config\Database::connect();
            $builder = $db->table('sub_category');
           $query   = $builder->get(); 

//$sql = $builder->getCompiledSelect();

echo $builder->limit(10,20)->getCompiledSelect(false);


//echo $builder->select('title, content, date')->getCompiledSelect();
//$query = $builder->getWhere(['id' => $id], $limit, $offset);
//echo $sql; die;

$sql = $builder->select(['name','description'])
              // ->where('id',5)
               ->getCompiledSelect(false);
echo $sql; die;
// ...
// Do something crazy with the SQL code... like add it to a cron script for
// later execution or something...
// ...

//$data = $builder->get()->getResultArray();
//return $data;
//echo '<pre>' ;print_r($data) ;die;

}
}