<?php  
defined('BASEPATH') OR exit('No direct script access allowed'); 
class Category_model extends CI_Model { 
    public function __construct() { 
        parent::__construct(); 
    }
    private $_category = 'category';  
    
    
    public function get_category_info() { 
        $this->db->select('*') 
                ->from('category')
                ->where('is_deleted', 0)
                ;
        $query_result = $this->db->get(); 
        $result = $query_result->result_array(); 
        return $result; 
    } 

    
    
}

