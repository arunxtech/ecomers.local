<?php namespace App\Models\admin_models;
use CodeIgniter\Model;
class Brand_model extends Model
{
    protected $table      = 'brand';
    protected $primaryKey = 'id';
    protected $allowedFields = ['id','name', 'description','is_deleted'];
    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;

}