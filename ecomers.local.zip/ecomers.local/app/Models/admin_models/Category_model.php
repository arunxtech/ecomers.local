<?php namespace App\Models\admin_models;
use CodeIgniter\Model;
class Category_model extends Model
{
    protected $table      = 'category';
    protected $primaryKey = 'id';
    protected $allowedFields = ['id','name', 'description','display_order','is_deleted'];
    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;
}