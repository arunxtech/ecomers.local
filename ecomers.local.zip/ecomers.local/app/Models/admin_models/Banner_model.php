<?php namespace App\Models\admin_models;
use CodeIgniter\Model;
class Banner_model extends Model
{
    protected $table      = 'banner';
    protected $primaryKey = 'id';
    protected $allowedFields = ['id','type','heading1','heading2','anchor_title','image_url','anchor_url','custom_page_id','is_deleted'];
    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;

}