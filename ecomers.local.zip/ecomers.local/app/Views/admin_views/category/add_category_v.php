<div id="main">
      <div class="row">
        <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
        <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
          <!-- Search for small screen-->
          <div class="container">
            <div class="row">
              <div class="col s10 m6 l6">
               
                <ol class="breadcrumbs mb-0">
                  <li class="breadcrumb-item"><a href="<?php  echo base_url('/admin/dashboard') ?>">Home</a>
                  </li>
                  <li class="breadcrumb-item"><a href="<?php  echo base_url('/admin/category') ?>">Manage Category</a>
                  </li>
                  <li class="breadcrumb-item active">Add Category
                  </li>
                </ol>
              </div>
             <div class="col s2 m6 l6"><a class="btn dropdown-settings waves-effect waves-light breadcrumbs-btn right" href="#!" data-target="dropdown1"><i class="material-icons hide-on-med-and-up">settings</i><span class="hide-on-small-onl">Settings</span><i class="material-icons right">arrow_drop_down</i></a>
                <ul class="dropdown-content" id="dropdown1" tabindex="0">
                  <li tabindex="0"><a class="grey-text text-darken-2" href="<?php  echo base_url('/admin/dashboard') ?>">Profile<span class="new badge red">2</span></a></li>
                  <li tabindex="0"><a class="grey-text text-darken-2" href="<?php  echo base_url('/admin/dashboard') ?>">Contacts</a></li>
                  <li tabindex="0"><a class="grey-text text-darken-2" href="<?php  echo base_url('/admin/dashboard') ?>">FAQ</a></li>
                  <li class="divider" tabindex="-1"></li>
                  <li tabindex="0"><a class="grey-text text-darken-2" href="<?php  echo base_url('/admin/dashboard') ?>l">Logout</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col s12">
          <div class="container">
            <div class="seaction">
                <div class="row">
    <div class="col s12">
      <div id="basic-form" class="card card card-default scrollspy">
        <div class="card-content">
            <?= \Config\Services::validation()->listErrors(); ?>
		<?= \Config\Services::session()->getFlashdata('msg'); ?>
          <form role="form" name="add_form" action="<?= base_url() ?>/admin/category/create_category" method="post"  class="form-validation" >
              		
           		     <input type="hidden" name="id" class="form-control" id="id" value=""> 
        
           <div class="row">
              <div class="input-field col s12">
                <input type="text" name="name" class="form-control" placeholder="Enter Name" id="name">
                <label for="name">Name</label>
              </div>
            </div>
              <div class="row">
              <div class="input-field col s12">
                <textarea id="description"  name="description"  class="materialize-textarea"></textarea>
                <label for="description">Description</label>
              </div>
              <div class="row">
                <div class="input-field col s12">
                  <button class="btn cyan waves-effect waves-light right" type="submit" name="action">Submit
                    <i class="material-icons right">send</i>
                  </button>
                    
                   
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>

   
  </div>
            </div>


          </div>
          <div class="content-overlay"></div>
        </div>
      </div>
    </div>

