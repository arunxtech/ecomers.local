<?php
namespace App\Controllers\admin;
use App\Controllers\BaseController;

class Dashboard extends BaseController{
    

   public function index() {


        
         $data = [
                        'title' => 'Your title',
                        'main_menu' => 'Main Menu',
                        'main_content'=>'Main Content'
                ];

                echo view('admin_views/main_menu_v', $data);
               echo view('admin_views/dashboard/dashboard_v', $data);
                echo view('admin_views/admin_master_v', $data);
              
        
      
	
   
   }
}
