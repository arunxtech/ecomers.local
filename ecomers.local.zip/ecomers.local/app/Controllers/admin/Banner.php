<?php namespace App\Controllers\admin;
use App\Controllers\BaseController;
use codeigniter\Controller;
use App\Models\admin_models\Banner_model;
class Banner extends BaseController{
 public function __construct(){
    }
        public function index() {
       $data = [
                    'title' => 'Your title',
                    'main_menu' => 'Main Menu',
                    'main_content'=>'Main Content'
                ];
                $model = new Banner_model();
                $data['bannerData'] = $model->where('is_deleted', 'false')
                                           ->orderBy('id','DESC')->paginate(10);
                $data['pagination_link'] =$model->pager;
                //echo '<pre>' ;print_r($data) ;die;
                echo view('admin_views/main_menu_v', $data);
                echo view('admin_views/banner/manage_banner_v', $data);
                echo view('admin_views/admin_master_v', $data);
}
        public function add_banner(){
		$data['title']   = "Banner";
                echo view('admin_views/main_menu_v', $data);
                echo view('admin_views/banner/add_banner_v', $data);
                echo view('admin_views/admin_master_v', $data);
		
	}
	public function create_banner(){
		$data = $this->request->getVar();
                $validation =  \Config\Services::validation();
		$validation->setRules([
			'type' => 'required|string|trim|max_length[250]|min_length[2]',
			'heading1' => 'required|string|trim|max_length[250]|min_length[1]',
                        'heading2' => 'required|string|trim|max_length[250]|min_length[2]',
                        'anchor_title' => 'required|string|trim|max_length[250]|min_length[2]',
		]);
		$res = $validation->withRequest($this->request)
			->run();
                if(!$res){
                        $data['title'] = "Contact";
			echo view('banner',$data, [
					'validation' => $validation
			]);
		}
		else{
                    $session = \Config\Services::session();
			try{
				$model = new Banner_model();
                                $addData = array(
                                     'heading1'=>$data['heading1'],
                                     'heading2'=>$data['heading2'],
                                     'anchor_title'=>$data['anchor_title'],
                                     'type'=>$data['type'],
                                    'image_url'=>'images\harmonysofa1.jpg',
                                    'anchor_url'=>'images\shopnow.jpg',
                                    'custom_page_id'=>'1',
                                     'is_deleted'=>'false',
                                    'id'=>'7',
                                 );
                                
                                
                               
                                 $user=$model->insert($addData);
                                  //echo '<pre>' ;print_r($user) ;die;
                                 $session->setFlashdata('msg', 'Record Inserted successfully');
			}
			catch(\Exception $e){
				$session->setFlashdata('msg', 'Something went wrong');
			}
			$data['title'] = "banner";
			return redirect()->to( base_url('admin/banner') );
                }
		
	}
        public function edit_banner($id = null){
		$model = new Banner_model();
		$data['user'] = $model->where('id', $id)->first();
		echo view('admin_views/main_menu_v', $data);
                echo view('admin_views/banner/edit_banner_v', $data);
                echo view('admin_views/admin_master_v', $data);
    }
	public function update_banner($id = null){
		$data = $this->request->getVar();
		$id = $this->request->getVar('id');
		$validation =  \Config\Services::validation();
		$validation->setRules([
			'type' => 'required|string|trim|max_length[250]|min_length[2]',
			'heading1' => 'required|string|trim|max_length[250]|min_length[1]',
                        'heading2' => 'required|string|trim|max_length[250]|min_length[2]',
                        'anchor_title' => 'required|string|trim|max_length[250]|min_length[2]',
		]);
		$res = $validation->withRequest($this->request)
			->run();
		if(!$res){
		
			$data['title'] = "Banner";
			echo view('banner',$data, [
					'validation' => $validation
			]);
		}
		else{
                    $session = \Config\Services::session();
			try{
				$model = new Banner_model();
				$user=$model->update($id,$data);
				$session->setFlashdata('msg', 'Record Updated successfully');
			}
			catch(\Exception $e){
				$session->setFlashdata('msg', 'Something went wrong');
			}
			$data['title'] = "Contact";
			return redirect()->to( base_url('admin/banner') );
		}
	}
	public function delete($id = null){
		$model = new Banner_model();
                $addData = array(
                    'is_deleted'=>'true',
                                   
                                 );
                $user=$model->update($id,$addData);
//		$data['user'] = $model->where('id', $id)->delete();
		return redirect()->to( base_url('admin/banner') );
    }
}
