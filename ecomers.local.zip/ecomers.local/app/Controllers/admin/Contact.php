<?php namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\admin_models\ContactModel;
class Contact extends BaseController
{
	public function __construct(){
    }
	public function index()
	{
		$data['title']   = "Contact List";
		$model = new ContactModel();
		$data['posts'] = $model->findAll();
		
		return view('view',$data);
	}
	
}