<?php namespace App\Controllers\admin;
use App\Controllers\BaseController;
use codeigniter\Controller;
use App\Models\admin_models\Brand_model;
class Brand extends BaseController{
 public function __construct(){
    }
        public function index() {
       $data = [
                    'title' => 'Your title',
                    'main_menu' => 'Main Menu',
                    'main_content'=>'Main Content'
                ];
                $model = new Brand_model();
                $data['brandData'] = $model->where('is_deleted', '0')
                                           ->orderBy('id','DESC')->paginate(10);
                $data['pagination_link'] =$model->pager;
                //echo '<pre>' ;print_r($data) ;die;
                echo view('admin_views/main_menu_v', $data);
                echo view('admin_views/brand/manage_brand_v', $data);
                echo view('admin_views/admin_master_v', $data);
}
        public function add_brand(){
		$data['title']   = "Brand";
                echo view('admin_views/main_menu_v', $data);
                echo view('admin_views/brand/add_brand_v', $data);
                echo view('admin_views/admin_master_v', $data);
		
	}
	public function create_brand(){
		$data = $this->request->getVar();
                $validation =  \Config\Services::validation();
		$validation->setRules([
			'name' => 'required|string|trim|max_length[250]|min_length[2]',
			'description' => 'string',
		]);
		$res = $validation->withRequest($this->request)
			->run();
                if(!$res){
                        $data['title'] = "Contact";
			echo view('brand',$data, [
					'validation' => $validation
			]);
		}
		else{
                    $session = \Config\Services::session();
			try{
				$model = new Brand_model();
                                $addData = array(
                                     'name'=>$data['name'],
                                     'description'=>$data['description'],
                                     'is_deleted'=>'0',
                                 );
                                
                                 $user=$model->insert($addData);
                                 $session->setFlashdata('msg', 'Record Inserted successfully');
			}
			catch(\Exception $e){
				$session->setFlashdata('msg', 'Something went wrong');
			}
			$data['title'] = "brand";
			return redirect()->to( base_url('admin/brand') );
                }
		
	}
        public function edit_brand($id = null){
		$model = new Brand_model();
		$data['user'] = $model->where('id', $id)->first();
		echo view('admin_views/main_menu_v', $data);
                echo view('admin_views/brand/edit_brand_v', $data);
                echo view('admin_views/admin_master_v', $data);
    }
	public function update_brand($id = null){
		$data = $this->request->getVar();
		$id = $this->request->getVar('id');
		$validation =  \Config\Services::validation();
		$validation->setRules([
			'name' => 'required|string|trim|max_length[250]|min_length[2]',
			'description' => 'string',
		]);
		$res = $validation->withRequest($this->request)
			->run();
		if(!$res){
		
			$data['title'] = "Brand";
			echo view('brand',$data, [
					'validation' => $validation
			]);
		}
		else{
                    $session = \Config\Services::session();
			try{
				$model = new Brand_model();
				$user=$model->update($id,$data);
				$session->setFlashdata('msg', 'Record Updated successfully');
			}
			catch(\Exception $e){
				$session->setFlashdata('msg', 'Something went wrong');
			}
			$data['title'] = "Contact";
			return redirect()->to( base_url('admin/brand') );
		}
	}
	public function delete($id = null){
		$model = new Brand_model();
                $addData = array(
                    'is_deleted'=>'1',
                                   
                                 );
                $user=$model->update($id,$addData);
//		$data['user'] = $model->where('id', $id)->delete();
		return redirect()->to( base_url('admin/brand') );
    }
}
