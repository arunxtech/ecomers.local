<?php namespace App\Controllers\admin;
use App\Controllers\BaseController;
use codeigniter\Controller;
use App\Models\admin_models\Category_model;
class Category extends BaseController{
    public function __construct(){
        }
        public function index() {
       $data = [
                    'title' => 'Your title',
                    'main_menu' => 'Main Menu',
                    'main_content'=>'Main Content'
                ];
                $model = new Category_model();
                $data['categoryData'] = $model->where('is_deleted', 'false')
                                              ->orderBy('id','DESC')->paginate(10);
                $data['pagination_link'] =$model->pager;
                echo view('admin_views/main_menu_v', $data);
                echo view('admin_views/category/manage_category_v', $data);
                echo view('admin_views/admin_master_v', $data);
}
        public function add_category(){
		$data['title']   = "Category";
                echo view('admin_views/main_menu_v', $data);
                echo view('admin_views/category/add_category_v', $data);
                echo view('admin_views/admin_master_v', $data);
		
	}
	public function create_category(){
		$data = $this->request->getVar();
                $validation =  \Config\Services::validation();
		$validation->setRules([
			'name' => 'required|string|trim|max_length[250]|min_length[2]',
			'description' => 'string',
		]);
		$res = $validation->withRequest($this->request)
			->run();
               
                if(!$res){
                        $data['title'] = "Contact";
			echo view('category',$data, [
					'validation' => $validation
			]);
		}
		else{
                    $session = \Config\Services::session();
			try{
				$model = new Category_model();
                                $addData = array(
                                     'name'=>$data['name'],
                                     'description'=>$data['description'],
                                     'is_deleted'=>'0',
                                     'display_order'=>'0'
                                 );
                                 
                                 $user=$model->insert($addData);
                                 $session->setFlashdata('msg', 'Record Inserted successfully');
			}
			catch(\Exception $e){
				$session->setFlashdata('msg', 'Something went wrong');
                                  //echo '<pre>' ;print_r($res);die;
			}
                      
			
			return redirect()->to( base_url('admin/category') );
                }
		
	}
        public function edit_category($id = null){
		$model = new Category_model();
		$data['user'] = $model->where('id', $id)->first();
		echo view('admin_views/main_menu_v', $data);
                echo view('admin_views/category/edit_category_v', $data);
                echo view('admin_views/admin_master_v', $data);
    }
	public function update_category($id = null){
		$data = $this->request->getVar();
		$id = $this->request->getVar('id');
		$validation =  \Config\Services::validation();
		$validation->setRules([
			'name' => 'required|string|trim|max_length[250]|min_length[2]',
			'description' => 'string',
		]);
		$res = $validation->withRequest($this->request)
			->run();
		if(!$res){
		
			$data['title'] = "Category";
			echo view('category',$data, [
					'validation' => $validation
			]);
		}
		else{
			
			$session = \Config\Services::session();
			try{
				$model = new Category_model();
				$user=$model->update($id,$data);
				$session->setFlashdata('msg', 'Record Updated successfully');
			}
			catch(\Exception $e){
				$session->setFlashdata('msg', 'Something went wrong');
			}
			$data['title'] = "Contact";
			return redirect()->to( base_url('admin/category') );
		}
	}
	public function delete($id = null){
            $model = new Category_model();
            $addData = array(
                    'is_deleted'=>'true',
                                   
                                 );
                $user=$model->update($id,$addData);
            return redirect()->to( base_url('admin/category') );
    }
}
