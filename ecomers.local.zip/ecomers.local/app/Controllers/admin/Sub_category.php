<?php namespace App\Controllers\admin;
use App\Controllers\BaseController;
use codeigniter\Controller;
use App\Models\admin_models\sub_category_model;
use App\Models\admin_models\category_model;
class Sub_category extends BaseController{
public function __construct(){
    }
        public function index() {
                $data = [
                    'title' => 'Your title',
                    'main_menu' => 'Main Menu',
                    'main_content'=>'Main Content'
                ];
               $column_name = 'is_deleted';
                $model = new sub_category_model();
                $data['sub_categoryData'] = $model->where('is_deleted', 'false')
                                                  ->orderBy('id','DESC')->paginate(10);
             // $data['user'] = $model->findColumn($column_name);
                
               // echo '<pre>' ;print_r($data);die;
                $data['pagination_link'] =$model->pager;
                echo view('admin_views/main_menu_v', $data);
                echo view('admin_views/sub_category/manage_sub_category_v', $data);
                echo view('admin_views/admin_master_v', $data);
}
        public function add_sub_category(){
		$data['title']   = "sub_category";
                $model = new sub_category_model();
                $data['categoryDropdown'] = $model->findAll();
               // echo '<pre>' ;print_r($data['categoryDropdown']); die;
                echo view('admin_views/main_menu_v', $data);
                echo view('admin_views/sub_category/add_sub_category_v', $data);
                echo view('admin_views/admin_master_v', $data);
		
	}
	public function create_sub_category(){
		$data = $this->request->getVar();
                $validation =  \Config\Services::validation();
		$validation->setRules([
			'name' => 'required|string|trim|max_length[250]|min_length[2]',
                        'description' => 'string',
			
		]);
		$res = $validation->withRequest($this->request)
			->run();
                if(!$res){
                        $data['title'] = "Sub_category";
			echo view('sub_category',$data, [
					'validation' => $validation
			]);
		}
		else{
                    $session = \Config\Services::session();
			try{
				$model = new sub_category_model();
                                $addData = array(
                                     'name'=>$data['name'],
                                     'description'=>$data['description'],
                                     'is_deleted'=>'false',
                                    'display_order'=>'11',
                                    'category_id'=>$data['category_id']
                                 );
                                
                                //echo '<pre>' ;print_r($addData);die;
                                 $user=$model->insert($addData);
                                // echo '<pre>' ;print_r($user);die;
                                 $session->setFlashdata('msg', 'Record Inserted successfully');
			}
			catch(\Exception $e){
				$session->setFlashdata('msg', 'Something went wrong');
			}
			return redirect()->to( base_url('admin/sub_category') );
                }
		
	}
        public function edit_sub_category($id = null){
		$model = new sub_category_model();
		$data['user'] = $model->where('id', $id)->first();
                 $data['categoryDropdown'] = $model->findAll();
		echo view('admin_views/main_menu_v', $data);
                echo view('admin_views/sub_category/edit_sub_category_v', $data);
                echo view('admin_views/admin_master_v', $data);
    }
	public function update_sub_category($id = null){
		$data = $this->request->getVar();
		$id = $this->request->getVar('id');
		$validation =  \Config\Services::validation();
		$validation->setRules([
			'name' => 'required|string|trim|max_length[250]|min_length[2]',
                        'description' => 'string',
		]);
		$res = $validation->withRequest($this->request)->run();
		if(!$res){
                        $data['title'] = "sub_category";
			echo view('sub_category',$data, ['validation' => $validation]);
		}
		else{
                    $session = \Config\Services::session();
			try{
				$model = new sub_category_model();
				$user=$model->update($id,$data);
				$session->setFlashdata('msg', 'Record Updated successfully');
			}
			catch(\Exception $e){
				$session->setFlashdata('msg', 'Something went wrong');
			}
                        return redirect()->to( base_url('admin/sub_category') );
		}
	}
	public function delete($id = null){
		$model = new sub_category_model();
		$addData = array(
                    'is_deleted'=>'true',
                                   
                                 );
                $user=$model->update($id,$addData);
		return redirect()->to( base_url('admin/sub_category') );
    }
}
