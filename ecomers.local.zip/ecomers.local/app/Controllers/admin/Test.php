<?php
namespace App\Controllers\admin;
use App\Controllers\BaseController;

class Test extends BaseController
{
	public function index()
	{
		return view('welcome_message');
	}

	//--------------------------------------------------------------------

}
